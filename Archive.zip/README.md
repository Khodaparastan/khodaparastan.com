# My farsi website base on jekyll
I'm Pooya Golchian, who loves OpenSource and Programming.

See my weblog and projects  >>>>> [pooyagolchian.ir](http://pooya-golchian.github.io)

This theme base on jekell, bourbon, neat, sass.

## Features:

* Compatible with Jekyll 3 and GitHub Pages.
* Responsive templates.
* Gracefully degrading in older browsers. Compatible with Internet Explorer 9+ and all modern browsers.
* Minimal embellishments and subtle animations.
* Optional large feature images for posts and pages.
* Support for Disqus Comments

See a [live version of My New Jekyll Theme](http://pooya-golchian.github.io)

Fork and enjoy!
