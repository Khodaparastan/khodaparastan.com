# Sallar.me

This is the home of my blog published in two languages. This repo uses [Mira](https://miraxy.github.io/) a static website generator written in Perl.

## Building

``` bash
$ yarn
$ yarn build
```

## License

Licensed under the [MIT License](LICENSE).

Content is licensed under [CC BY-NC-ND 3.0](https://creativecommons.org/licenses/by-nc-nd/3.0/)
